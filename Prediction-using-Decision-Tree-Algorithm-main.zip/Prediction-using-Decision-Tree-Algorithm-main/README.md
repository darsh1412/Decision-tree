# Prediction-using-Decision-Tree-Algorithm

Project:-Decision Tree

Create the Decision Tree classifier and visualize it graphically.

The purpose is if we feed any new data to this classifier, it would be able to predict the right class accordingly.

Please find the following files:

        1. Required .ipynb file.
        
        2.Provided data.
        
        3.Decision Tree in .png file form.
